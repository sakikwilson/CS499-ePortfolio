const state = {
  currentUser: null,
  view: 'login',
  startDate: '',
  endDate: '',
  minWeight: '',
  maxWeight: '',
  editingEntryDate: null
};

function normalizeUnit(unit) {
  if (!unit) return 'lb';
  return unit.toLowerCase() === 'kg' ? 'lb' : unit.toLowerCase();
}

const loginView = document.getElementById('loginView');
const homeView = document.getElementById('homeView');
const settingsView = document.getElementById('settingsView');
const settingsButton = document.getElementById('settingsButton');
const backToHomeButton = document.getElementById('backToHomeButton');

const loginForm = document.getElementById('loginForm');
const loginUsername = document.getElementById('loginUsername');
const loginPassword = document.getElementById('loginPassword');
const loginMessage = document.getElementById('loginMessage');

const goalWeightText = document.getElementById('goalWeightText');
const latestWeightText = document.getElementById('latestWeightText');
const historyList = document.getElementById('historyList');
const trendChart = document.getElementById('trendChart');
const filterForm = document.getElementById('filterForm');
const filtersToggle = document.getElementById('filtersToggle');
const resetFiltersButton = document.getElementById('resetFiltersButton');
const startDate = document.getElementById('startDate');
const endDate = document.getElementById('endDate');
const minWeight = document.getElementById('minWeight');
const maxWeight = document.getElementById('maxWeight');
const entryForm = document.getElementById('entryForm');
const entryDate = document.getElementById('entryDate');
const entryWeight = document.getElementById('entryWeight');
const entryMessage = document.getElementById('entryMessage');

const settingsForm = document.getElementById('settingsForm');
const settingsUsername = document.getElementById('settingsUsername');
const settingsNewPassword = document.getElementById('settingsNewPassword');
const settingsGoalWeight = document.getElementById('settingsGoalWeight');
const settingsUnit = document.getElementById('settingsUnit');
const settingsSms = document.getElementById('settingsSms');
const settingsMessage = document.getElementById('settingsMessage');

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  loginMessage.textContent = 'Signing in...';

  const response = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: loginUsername.value.trim(),
      password: loginPassword.value.trim()
    })
  });

  const payload = await response.json();
  if (!payload.success) {
    loginMessage.textContent = payload.message || 'Unable to sign in';
    return;
  }

  state.currentUser = {
    ...payload.user,
    password: loginPassword.value.trim(),
    unit: normalizeUnit(payload.user.unit)
  };
  state.view = 'home';
  settingsButton.hidden = false;
  render();
  loginMessage.textContent = payload.created === 'true' ? 'New account created.' : 'Signed in.';
});

settingsButton.addEventListener('click', () => {
  state.view = 'settings';
  populateSettingsForm();
  render();
});

backToHomeButton.addEventListener('click', () => {
  state.view = 'home';
  render();
});

filtersToggle.addEventListener('click', () => {
  const isHidden = filterForm.hidden;
  filterForm.hidden = !isHidden;
  filtersToggle.textContent = isHidden ? 'Filters ▴' : 'Filters ▾';
});

filterForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  state.startDate = startDate.value;
  state.endDate = endDate.value;
  state.minWeight = minWeight.value;
  state.maxWeight = maxWeight.value;
  await loadHomeData();
});

resetFiltersButton.addEventListener('click', async () => {
  state.startDate = '';
  state.endDate = '';
  state.minWeight = '';
  state.maxWeight = '';
  filterForm.reset();
  await loadHomeData();
});

entryForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  entryMessage.textContent = 'Adding entry...';

  const response = await fetch('/api/entry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: state.currentUser.username,
      password: state.currentUser.password,
      action: 'add',
      date: entryDate.value,
      weight: entryWeight.value
    })
  });

  const payload = await response.json();
  if (!payload.success) {
    entryMessage.textContent = payload.message || 'Unable to add entry';
    return;
  }

  state.currentUser = payload.user;
  entryMessage.textContent = 'Entry added.';
  entryForm.reset();
  renderHome();
});

settingsForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  settingsMessage.textContent = 'Saving...';

  const response = await fetch('/api/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: state.currentUser.username,
      password: state.currentUser.password,
      newUsername: settingsUsername.value.trim(),
      newPassword: settingsNewPassword.value.trim(),
      goalWeight: settingsGoalWeight.value,
      unit: settingsUnit.value,
      smsNotifications: settingsSms.checked
    })
  });

  const payload = await response.json();
  if (!payload.success) {
    settingsMessage.textContent = payload.message || 'Unable to save settings';
    return;
  }

  state.currentUser = {
    ...payload.user,
    password: settingsNewPassword.value.trim() ? settingsNewPassword.value.trim() : state.currentUser.password,
    unit: normalizeUnit(payload.user.unit)
  };
  settingsMessage.textContent = 'Settings updated.';
  render();
});

async function loadHomeData() {
  if (!state.currentUser) return;

  const params = new URLSearchParams({
    username: state.currentUser.username,
    startDate: state.startDate,
    endDate: state.endDate,
    minWeight: state.minWeight,
    maxWeight: state.maxWeight
  });
  const response = await fetch('/api/history?' + params.toString());
  const payload = await response.json();
  if (!payload.success) {
    return;
  }

  renderHistory(payload.entries || []);
}

function render() {
  loginView.hidden = state.view !== 'login';
  homeView.hidden = state.view !== 'home';
  settingsView.hidden = state.view !== 'settings';
  settingsButton.hidden = state.view === 'login' || state.view === 'settings' || !state.currentUser;

  if (state.view === 'home') {
    renderHome();
  }
}

function renderHome() {
  if (!state.currentUser) return;
  goalWeightText.textContent = `${state.currentUser.goalWeight} ${state.currentUser.unit}`;
  const latestEntry = state.currentUser.entries?.length ? state.currentUser.entries[state.currentUser.entries.length - 1] : null;
  latestWeightText.textContent = latestEntry ? `${latestEntry.weight} ${state.currentUser.unit}` : 'No entries yet';
  renderHistory(state.currentUser.entries || []);
}

function renderHistory(entries) {
  const filtered = entries.filter((entry) => {
    if (state.startDate && entry.date < state.startDate) return false;
    if (state.endDate && entry.date > state.endDate) return false;

    const minWeightValue = Number(state.minWeight);
    if (!Number.isNaN(minWeightValue) && state.minWeight !== '' && entry.weight < minWeightValue) return false;

    const maxWeightValue = Number(state.maxWeight);
    if (!Number.isNaN(maxWeightValue) && state.maxWeight !== '' && entry.weight > maxWeightValue) return false;

    return true;
  });

  historyList.innerHTML = '';
  if (!filtered.length) {
    const item = document.createElement('li');
    item.textContent = 'No entries in the selected window.';
    historyList.appendChild(item);
    drawChart([]);
    return;
  }

  const orderedEntries = [...filtered].sort((a, b) => b.date.localeCompare(a.date));

  orderedEntries.forEach((entry) => {
    const item = document.createElement('li');
    item.className = 'history-entry';

    if (state.editingEntryDate === entry.date) {
      const editForm = document.createElement('form');
      editForm.className = 'inline-edit-form';

      const dateLabel = document.createElement('span');
      dateLabel.textContent = entry.date;

      const weightInput = document.createElement('input');
      weightInput.type = 'number';
      weightInput.step = '0.1';
      weightInput.value = entry.weight;

      const saveButton = document.createElement('button');
      saveButton.type = 'submit';
      saveButton.className = 'icon-button';
      saveButton.textContent = '✓';
      saveButton.title = 'Save';

      const cancelButton = document.createElement('button');
      cancelButton.type = 'button';
      cancelButton.className = 'icon-button';
      cancelButton.textContent = '✕';
      cancelButton.title = 'Cancel';
      cancelButton.addEventListener('click', () => {
        state.editingEntryDate = null;
        renderHome();
      });

      editForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        await saveEditedEntry(entry, weightInput.value);
      });

      editForm.appendChild(dateLabel);
      editForm.appendChild(weightInput);
      editForm.appendChild(saveButton);
      editForm.appendChild(cancelButton);
      item.appendChild(editForm);
    } else {
      const text = document.createElement('span');
      text.textContent = `${entry.date}: ${entry.weight} ${state.currentUser.unit}`;

      const actions = document.createElement('div');
      actions.className = 'entry-actions';

      const editButton = document.createElement('button');
      editButton.className = 'icon-button';
      editButton.type = 'button';
      editButton.textContent = '✎';
      editButton.title = 'Update';
      editButton.addEventListener('click', () => {
        state.editingEntryDate = entry.date;
        renderHome();
      });

      const deleteButton = document.createElement('button');
      deleteButton.className = 'icon-button';
      deleteButton.type = 'button';
      deleteButton.textContent = '🗑';
      deleteButton.title = 'Delete';
      deleteButton.addEventListener('click', () => handleDeleteEntry(entry));

      actions.appendChild(editButton);
      actions.appendChild(deleteButton);
      item.appendChild(text);
      item.appendChild(actions);
    }

    historyList.appendChild(item);
  });
  drawChart(filtered);
}

async function saveEditedEntry(entry, newWeight) {
  const trimmedWeight = newWeight?.trim();
  if (!trimmedWeight) {
    return;
  }

  const response = await fetch('/api/entry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: state.currentUser.username,
      password: state.currentUser.password,
      action: 'update',
      entryDate: entry.date,
      weight: trimmedWeight
    })
  });

  const payload = await response.json();
  if (!payload.success) {
    return;
  }

  state.currentUser = payload.user;
  state.editingEntryDate = null;
  renderHome();
}

async function handleDeleteEntry(entry) {
  const confirmed = window.confirm(`Delete the weight entry for ${entry.date}?`);
  if (!confirmed) {
    return;
  }

  const response = await fetch('/api/entry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: state.currentUser.username,
      password: state.currentUser.password,
      action: 'delete',
      entryDate: entry.date
    })
  });

  const payload = await response.json();
  if (!payload.success) {
    return;
  }

  state.currentUser = payload.user;
  renderHome();
}

function drawChart(entries) {
  const width = 360;
  const height = 220;
  const padding = 24;
  if (!entries.length) {
    trendChart.innerHTML = '<text x="50%" y="50%" text-anchor="middle" fill="#8fa7bf">Add a weight entry to see the trend.</text>';
    return;
  }

  const sortedEntries = [...entries].sort((a, b) => a.date.localeCompare(b.date));
  const values = sortedEntries.map((entry) => Number(entry.weight));
  const dataMin = Math.min(...values);
  const dataMax = Math.max(...values);
  const min = dataMin - 5;
  const max = dataMax + 5;
  const scaleValue = (value) => {
    const range = max - min || 1;
    const normalized = (Number(value) - min) / range;
    return height - padding - normalized * (height - padding * 2);
  };

  const stepX = (width - padding * 2) / Math.max(sortedEntries.length - 1, 1);
  const points = sortedEntries.map((entry, index) => {
    const x = padding + index * stepX;
    const y = scaleValue(entry.weight);
    return `${x},${y}`;
  });

  const unit = state.currentUser?.unit || 'lb';
  const axisLabelSize = '10';
  const circles = sortedEntries.map((entry, index) => {
    const x = padding + index * stepX;
    const y = scaleValue(entry.weight);
    const tooltipText = `${entry.date}: ${entry.weight} ${unit}`;
    return `
      <g>
        <circle cx="${x}" cy="${y}" r="5" fill="#2f80ed" />
        <circle cx="${x}" cy="${y}" r="10" fill="transparent" stroke="transparent" cursor="pointer" data-tooltip="${tooltipText}" />
      </g>`;
  }).join('');

  const yTicks = [min, max].map((value) => {
    const y = scaleValue(value);
    return `<line x1="${padding - 4}" y1="${y}" x2="${padding}" y2="${y}" stroke="#4f6783" />`;
  }).join('');

  const polyline = `<polyline fill="none" stroke="#46c5ff" stroke-width="2.5" points="${points.join(' ')}" />`;
  trendChart.innerHTML = `
    <line x1="${padding}" y1="${height - padding}" x2="${width - padding}" y2="${height - padding}" stroke="#4f6783" />
    <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${height - padding}" stroke="#4f6783" />
    <text x="${padding - 16}" y="${height / 2}" font-size="${axisLabelSize}" text-anchor="middle" transform="rotate(-90 ${padding - 16} ${height / 2})" fill="#59708b">Weight</text>
    <text x="${width / 2}" y="${height - 4}" font-size="${axisLabelSize}" text-anchor="middle" fill="#59708b">Date</text>
    ${yTicks}
    ${polyline}
    ${circles}
  `;

  let tooltip = document.getElementById('chartTooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = 'chartTooltip';
    tooltip.className = 'chart-tooltip';
    trendChart.parentElement.appendChild(tooltip);
  }

  trendChart.querySelectorAll('circle[data-tooltip]').forEach((dot) => {
    dot.addEventListener('mouseenter', (event) => {
      tooltip.textContent = dot.getAttribute('data-tooltip');
      tooltip.style.display = 'block';
      const rect = trendChart.getBoundingClientRect();
      tooltip.style.left = `${event.clientX - rect.left + 10}px`;
      tooltip.style.top = `${event.clientY - rect.top - 12}px`;
    });
    dot.addEventListener('mousemove', (event) => {
      const rect = trendChart.getBoundingClientRect();
      tooltip.style.left = `${event.clientX - rect.left + 10}px`;
      tooltip.style.top = `${event.clientY - rect.top - 12}px`;
    });
    dot.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
    });
  });
}

function populateSettingsForm() {
  if (!state.currentUser) return;
  settingsUsername.value = state.currentUser.username;
  settingsGoalWeight.value = state.currentUser.goalWeight;
  settingsUnit.value = state.currentUser.unit || 'lb';
  settingsSms.checked = Boolean(state.currentUser.smsNotifications);
  settingsNewPassword.value = '';
}

async function bootstrap() {
  state.currentUser = null;
  state.view = 'login';
  render();
}

bootstrap();
