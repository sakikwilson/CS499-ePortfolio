public class WeightTrackerFilterTest {
    public static void main(String[] args) {
        UserProfile user = new UserProfile("tester", "secret");
        user.addEntry(new WeightEntry("2026-01-01", 120.0));
        user.addEntry(new WeightEntry("2026-01-02", 124.5));
        user.addEntry(new WeightEntry("2026-01-03", 126.0));

        int matches = WeightTracker.filterEntriesByWeight(user.getEntries(), 120.0, 125.0).size();
        if (matches != 2) {
            throw new IllegalStateException("Expected 2 entries within the weight range");
        }

        System.out.println("Weight range filter test passed");
    }
}
