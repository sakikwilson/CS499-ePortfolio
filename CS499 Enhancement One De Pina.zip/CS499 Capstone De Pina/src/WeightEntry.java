import java.util.LinkedHashMap;
import java.util.Map;

// Represents one recorded weight value for a specific date
public class WeightEntry {
    // The date for the weight reading
    protected String date;

    // The actual weight value recorded for that date
    protected double weight;

    // Creates a new entry with the supplied date and weight
    public WeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    // Converts the entry to a JSON-friendly structure for the UI
    public Map<String, String> toJsonMap() {
        Map<String, String> data = new LinkedHashMap<>();
        data.put("date", date);
        data.put("weight", String.valueOf(weight));
        return data;
    }
}
