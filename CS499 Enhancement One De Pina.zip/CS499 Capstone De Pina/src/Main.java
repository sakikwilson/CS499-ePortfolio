// Starts web server
public class Main {
    // Starts the weight tracker server when the program begins
    public static void main(String[] args) throws Exception {
        WeightTracker.main(args);
    }
}
