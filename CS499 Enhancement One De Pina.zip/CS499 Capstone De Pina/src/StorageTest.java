// Verifies the data model behaves correctly
public class StorageTest {
    // Runs a basic check on the model classes and prints a success message
    public static void main(String[] args) {
        UserProfile user = new UserProfile("tester", "secret");

        //Example inputted for testing
        user.addEntry(new WeightEntry("2026-01-01", 72.4));
        user.addEntry(new WeightEntry("2026-01-10", 71.7));

        //Verify if username mismatches expected value
        if (!user.getUsername().equals("tester")) {
            throw new IllegalStateException("Username mismatch");
        }

        //Verify if the number of entries matches the expected count
        if (user.getEntries().size() != 2) {
            throw new IllegalStateException("Entry count mismatch");
        }
        System.out.println("Storage test passed");
    }
}
