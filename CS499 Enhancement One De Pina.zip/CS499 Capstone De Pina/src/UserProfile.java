import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Stores one user account and user’s weight history
public class UserProfile {
    // Account Info
    protected String username;
    protected String password;
    protected double goalWeight = 70.0;
    protected String unit = "lb";
    protected boolean smsNotifications = false;

    // All historical weight entries
    protected final List<WeightEntry> entries = new ArrayList<>();

    // Creates a new profile 
    public UserProfile(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Converts the profile into a JSON-ready structure
    public Map<String, Object> toJsonMap() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", username);
        data.put("goalWeight", goalWeight);
        data.put("unit", unit);
        data.put("smsNotifications", smsNotifications);
        data.put("entries", entriesAsMaps());
        return data;
    }

    // Returns the username
    public String getUsername() {
        return username;
    }

    // Returns saved entries
    public List<WeightEntry> getEntries() {
        return entries;
    }

    // Adds a new entry or replaces existing one for same date
    public void addEntry(WeightEntry entry) {
        for (WeightEntry current : entries) {
            if (current.date.equals(entry.date)) {
                current.weight = entry.weight;
                return;
            }
        }
        entries.add(entry);
    }

    // Updates the weight for an existing entry
    public boolean updateEntry(String date, double weight) {
        for (WeightEntry current : entries) {
            if (current.date.equals(date)) {
                current.weight = weight;
                return true;
            }
        }
        return false;
    }

    // Deletes entry
    public boolean deleteEntry(String date) {
        return entries.removeIf(entry -> entry.date.equals(date));
    }

    // Converts every saved entry into a simple map for JSON output
    public List<Map<String, String>> entriesAsMaps() {
        List<Map<String, String>> output = new ArrayList<>();
        for (WeightEntry entry : entries) {
            output.add(entry.toJsonMap());
        }
        return output;
    }
}
