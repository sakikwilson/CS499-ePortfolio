import org.bson.Document;

public class MongoStorageTest {
    public static void main(String[] args) {
        UserProfile user = new UserProfile("mongoTester", "secret");
        user.addEntry(new WeightEntry("2026-02-01", 71.2));

        Document doc = MongoUserStore.toDocument(user);
        if (!"mongoTester".equals(doc.getString("username"))) {
            throw new IllegalStateException("Username was not serialized correctly");
        }

        if (doc.getList("entries", Document.class).size() != 1) {
            throw new IllegalStateException("Entry list was not serialized correctly");
        }

        System.out.println("Mongo storage test passed");
    }
}
