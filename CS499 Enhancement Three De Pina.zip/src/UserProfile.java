import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Stores one user account and the user's weight history.
public class UserProfile {
    // Account Info
    protected String username;
    protected String password;
    protected double goalWeight = 70.0;
    protected String unit = "lb";
    protected boolean smsNotifications = false;

    // All historical weight entries
    protected final List<WeightEntry> entries = new ArrayList<>();

    // Create a new profile with the supplied account credentials.
    public UserProfile(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Convert the profile into a JSON-ready structure for the UI and API.
    public Map<String, Object> toJsonMap() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", username);
        data.put("goalWeight", goalWeight);
        data.put("unit", unit);
        data.put("smsNotifications", smsNotifications);
        data.put("entries", entriesAsMaps());
        return data;
    }

    // Return the username.
    public String getUsername() {
        return username;
    }

    // Return the stored weight entries.
    public List<WeightEntry> getEntries() {
        return entries;
    }

    // Add a new entry or replace an existing entry for the same date.
    public void addEntry(WeightEntry entry) {
        for (WeightEntry current : entries) {
            if (current.date.equals(entry.date)) {
                current.weight = entry.weight;
                return;
            }
        }
        entries.add(entry);
    }

    // Update the weight for an existing entry.
    public boolean updateEntry(String date, double weight) {
        for (WeightEntry current : entries) {
            if (current.date.equals(date)) {
                current.weight = weight;
                return true;
            }
        }
        return false;
    }

    // Delete an entry by date.
    public boolean deleteEntry(String date) {
        return entries.removeIf(entry -> entry.date.equals(date));
    }

    // Convert every saved entry into a simple map for JSON output.
    public List<Map<String, String>> entriesAsMaps() {
        List<Map<String, String>> output = new ArrayList<>();
        for (WeightEntry entry : entries) {
            output.add(entry.toJsonMap());
        }
        return output;
    }
}
