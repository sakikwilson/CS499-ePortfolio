import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

public class WeightTracker {
    // Default server port for the local web app.
    private static final int DEFAULT_PORT = 8080;

    // Web server instance and MongoDB-backed store for user data.
    private final HttpServer server;
    private final MongoUserStore userStore;
    private final List<UserProfile> users = new ArrayList<>();

    public WeightTracker(int port) throws IOException {
        String connectionString = System.getenv().getOrDefault("MONGODB_URI", "mongodb://localhost:27017");
        String databaseName = System.getenv().getOrDefault("MONGODB_DATABASE", "weight-tracker");
        String collectionName = System.getenv().getOrDefault("MONGODB_COLLECTION", "users");
        this.userStore = new MongoUserStore(connectionString, databaseName, collectionName);
        loadUsers();

        this.server = HttpServer.create(new InetSocketAddress(port), 0);
        this.server.createContext("/", this::handleRoot);
        this.server.createContext("/styles.css", this::handleStaticFile);
        this.server.createContext("/app.js", this::handleStaticFile);
        this.server.createContext("/api/login", this::handleLogin);
        this.server.createContext("/api/user", this::handleUser);
        this.server.createContext("/api/history", this::handleHistory);
        this.server.createContext("/api/entry", this::handleEntry);
        this.server.createContext("/api/settings", this::handleSettings);
        this.server.setExecutor(Executors.newCachedThreadPool());
    }

    // Start the HTTP server and print the local address.
    public void start() {
        this.server.start();
        System.out.println("Weight tracker app is running on http://localhost:" + DEFAULT_PORT);
    }

    // Keep a small helper for the existing weight-filter tests.
    public static List<WeightEntry> filterEntriesByWeight(List<WeightEntry> entries, double minWeight, double maxWeight) {
        List<WeightEntry> filtered = new ArrayList<>();
        for (WeightEntry entry : entries) {
            if (entry.weight < minWeight || entry.weight > maxWeight) {
                continue;
            }
            filtered.add(entry);
        }
        return filtered;
    }

    // Launch the server from the application entry point.
    public static void main(String[] args) throws Exception {
        new WeightTracker(DEFAULT_PORT).start();
    }

    // Serve the main page from the web folder.
    private void handleRoot(HttpExchange exchange) throws IOException {
        serveFile(exchange, Paths.get("src", "web", "index.html"));
    }

    // Serve CSS and JavaScript assets from the web folder
    private void handleStaticFile(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        Path file = Paths.get("src", "web").resolve(path.startsWith("/") ? path.substring(1) : path);
        serveFile(exchange, file);
    }

    // Send a file back to the browser with the correct content type
    private void serveFile(HttpExchange exchange, Path file) throws IOException {
        if (!Files.exists(file)) {
            sendText(exchange, 404, "Not found");
            return;
        }

        byte[] data = Files.readAllBytes(file);
        String contentType = file.getFileName().toString().endsWith(".css") ? "text/css; charset=utf-8" : "text/html; charset=utf-8";
        if (file.getFileName().toString().endsWith(".js")) {
            contentType = "application/javascript; charset=utf-8";
        }
        exchange.getResponseHeaders().add("Content-Type", contentType);
        sendBytes(exchange, 200, data);
    }

    // Handle sign-in and account creation for the user.
    private void handleLogin(HttpExchange exchange) throws IOException {
        Map<String, String> body = readBody(exchange);
        String username = body.getOrDefault("username", "").trim();
        String password = body.getOrDefault("password", "").trim();

        if (username.isEmpty() || password.isEmpty()) {
            sendJson(exchange, 400, mapOf("success", "false", "message", "Username and password are required"));
            return;
        }

        UserProfile user = findUser(username);
        boolean created = false;
        if (user == null) {
            user = new UserProfile(username, password);
            users.add(user);
            created = true;
            saveUsers();
        } else if (!user.password.equals(password)) {
            sendJson(exchange, 401, mapOf("success", "false", "message", "Incorrect password"));
            return;
        }

        sendJson(exchange, 200, mapOf(
                "success", "true",
                "created", Boolean.toString(created),
                "user", user.toJsonMap()));
    }

    // Return the current user profile details for the signed-in user.
    private void handleUser(HttpExchange exchange) throws IOException {
        Map<String, String> query = parseQuery(exchange.getRequestURI().getQuery());
        String username = query.getOrDefault("username", "").trim();
        UserProfile user = findUser(username);
        if (user == null) {
            sendJson(exchange, 404, mapOf("success", "false", "message", "User not found"));
            return;
        }
        sendJson(exchange, 200, mapOf("success", "true", "user", user.toJsonMap()));
    }

    // Return the user's weight history, optionally filtered by date.
    private void handleHistory(HttpExchange exchange) throws IOException {
        Map<String, String> query = parseQuery(exchange.getRequestURI().getQuery());
        String username = query.getOrDefault("username", "").trim();
        UserProfile user = findUser(username);
        if (user == null) {
            sendJson(exchange, 404, mapOf("success", "false", "message", "User not found"));
            return;
        }

        String startDate = query.getOrDefault("startDate", "");
        String endDate = query.getOrDefault("endDate", "");
        String minWeight = query.getOrDefault("minWeight", "");
        String maxWeight = query.getOrDefault("maxWeight", "");
        List<Map<String, String>> filtered = new ArrayList<>();
        for (WeightEntry entry : user.entries) {
            if (!startDate.isEmpty() && entry.date.compareTo(startDate) < 0) {
                continue;
            }
            if (!endDate.isEmpty() && entry.date.compareTo(endDate) > 0) {
                continue;
            }
            if (!minWeight.isEmpty()) {
                try {
                    if (entry.weight < Double.parseDouble(minWeight)) {
                        continue;
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            if (!maxWeight.isEmpty()) {
                try {
                    if (entry.weight > Double.parseDouble(maxWeight)) {
                        continue;
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            filtered.add(entry.toJsonMap());
        }
        sendJson(exchange, 200, mapOf("success", "true", "entries", filtered));
    }

    // Add, update, or remove a weight entry for the signed-in user.
    private void handleEntry(HttpExchange exchange) throws IOException {
        Map<String, String> body = readBody(exchange);
        String username = body.getOrDefault("username", "").trim();
        String password = body.getOrDefault("password", "").trim();
        String action = body.getOrDefault("action", "add").trim().toLowerCase();
        String date = body.getOrDefault("date", "").trim();
        String entryDate = body.getOrDefault("entryDate", date).trim();
        String weight = body.getOrDefault("weight", "").trim();

        UserProfile user = findUser(username);
        if (user == null) {
            sendJson(exchange, 404, mapOf("success", "false", "message", "User not found"));
            return;
        }
        if (!user.password.equals(password)) {
            sendJson(exchange, 401, mapOf("success", "false", "message", "Incorrect password"));
            return;
        }

        if ("add".equals(action)) {
            if (date.isEmpty() || weight.isEmpty()) {
                sendJson(exchange, 400, mapOf("success", "false", "message", "Date and weight are required"));
                return;
            }
            user.addEntry(new WeightEntry(date, Double.parseDouble(weight)));
        } else if ("update".equals(action)) {
            if (entryDate.isEmpty() || weight.isEmpty()) {
                sendJson(exchange, 400, mapOf("success", "false", "message", "Entry date and weight are required"));
                return;
            }
            if (!user.updateEntry(entryDate, Double.parseDouble(weight))) {
                sendJson(exchange, 404, mapOf("success", "false", "message", "Entry not found"));
                return;
            }
        } else if ("delete".equals(action)) {
            if (entryDate.isEmpty()) {
                sendJson(exchange, 400, mapOf("success", "false", "message", "Entry date is required"));
                return;
            }
            if (!user.deleteEntry(entryDate)) {
                sendJson(exchange, 404, mapOf("success", "false", "message", "Entry not found"));
                return;
            }
        } else {
            sendJson(exchange, 400, mapOf("success", "false", "message", "Unknown action"));
            return;
        }

        user.entries.sort((a, b) -> a.date.compareTo(b.date));
        saveUsers();
        sendJson(exchange, 200, mapOf("success", "true", "user", user.toJsonMap()));
    }

    // Update profile settings and preferences for the signed-in user.
    private void handleSettings(HttpExchange exchange) throws IOException {
        Map<String, String> body = readBody(exchange);
        String username = body.getOrDefault("username", "").trim();
        String password = body.getOrDefault("password", "").trim();
        String newUsername = body.getOrDefault("newUsername", "").trim();
        String newPassword = body.getOrDefault("newPassword", "").trim();
        String goalWeight = body.getOrDefault("goalWeight", "").trim();
        String unit = body.getOrDefault("unit", "lb").trim();
        String smsNotifications = body.getOrDefault("smsNotifications", "false").trim();
        if (unit.isEmpty()) {
            unit = "lb";
        } else if ("kg".equalsIgnoreCase(unit)) {
            unit = "kg";
        }

        UserProfile user = findUser(username);
        if (user == null) {
            sendJson(exchange, 404, mapOf("success", "false", "message", "User not found"));
            return;
        }
        if (!user.password.equals(password)) {
            sendJson(exchange, 401, mapOf("success", "false", "message", "Incorrect password"));
            return;
        }

        if (!newUsername.isEmpty()) {
            user.username = newUsername;
        }
        if (!newPassword.isEmpty()) {
            user.password = newPassword;
        }
        if (!goalWeight.isEmpty()) {
            user.goalWeight = Double.parseDouble(goalWeight);
        }
        user.unit = unit.isEmpty() ? "lb" : unit;
        user.smsNotifications = Boolean.parseBoolean(smsNotifications);

        saveUsers();
        sendJson(exchange, 200, mapOf("success", "true", "user", user.toJsonMap()));
    }

    // Locate a user by username from the in-memory list
    private UserProfile findUser(String username) {
        for (UserProfile user : users) {
            if (user.username.equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }

    // Load saved users and entries from MongoDB when the server starts
    private void loadUsers() {
        users.clear();
        users.addAll(userStore.listAll());
    }

    // Persist the current user and entry data to MongoDB
    private void saveUsers() {
        for (UserProfile user : users) {
            userStore.save(user);
        }
    }

    // Read the request body as a simple map of values for the handler.
    private Map<String, String> readBody(HttpExchange exchange) throws IOException {
        String raw = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        if (raw.isEmpty()) {
            return Collections.emptyMap();
        }
        if (raw.startsWith("{")) {
            return parseJsonBody(raw);
        }

        Map<String, String> values = new HashMap<>();
        for (String pair : raw.split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts.length == 2) {
                values.put(parts[0], java.net.URLDecoder.decode(parts[1], StandardCharsets.UTF_8));
            }
        }
        return values;
    }

    // Parse a JSON body into a simple key/value map.
    private Map<String, String> parseJsonBody(String raw) {
        Map<String, String> values = new HashMap<>();
        int index = 0;
        while (index < raw.length()) {
            char current = raw.charAt(index);
            if (Character.isWhitespace(current)) {
                index++;
                continue;
            }
            if (current == '}') {
                break;
            }
            if (current != '"') {
                index++;
                continue;
            }

            int keyStart = index + 1;
            int keyEnd = findStringEnd(raw, keyStart);
            if (keyEnd < 0) {
                break;
            }
            String key = raw.substring(keyStart, keyEnd).replace("\\\"", "\"");
            index = keyEnd + 1;

            while (index < raw.length() && Character.isWhitespace(raw.charAt(index))) {
                index++;
            }
            if (index >= raw.length() || raw.charAt(index) != ':') {
                break;
            }
            index++;

            while (index < raw.length() && Character.isWhitespace(raw.charAt(index))) {
                index++;
            }
            if (index >= raw.length()) {
                break;
            }

            String value;
            if (raw.charAt(index) == '"') {
                int valueStart = index + 1;
                int valueEnd = findStringEnd(raw, valueStart);
                if (valueEnd < 0) {
                    break;
                }
                value = raw.substring(valueStart, valueEnd).replace("\\\"", "\"");
                index = valueEnd + 1;
            } else if (raw.charAt(index) == '{' || raw.charAt(index) == '[') {
                value = "";
                index++;
            } else {
                int valueStart = index;
                while (index < raw.length() && raw.charAt(index) != ',' && raw.charAt(index) != '}') {
                    index++;
                }
                value = raw.substring(valueStart, index).trim();
            }

            values.put(key, value);

            while (index < raw.length() && Character.isWhitespace(raw.charAt(index))) {
                index++;
            }
            if (index < raw.length() && raw.charAt(index) == ',') {
                index++;
            }
        }

        return values;
    }

    // Find the end of a JSON string value while respecting escapes.
    private int findStringEnd(String raw, int start) {
        boolean escaped = false;
        for (int index = start; index < raw.length(); index++) {
            char current = raw.charAt(index);
            if (escaped) {
                escaped = false;
                continue;
            }
            if (current == '\\') {
                escaped = true;
                continue;
            }
            if (current == '"') {
                return index;
            }
        }
        return -1;
    }

    // Parse query string parameters from the request URL
    private Map<String, String> parseQuery(String query) {
        if (query == null || query.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, String> values = new HashMap<>();
        for (String pair : query.split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts.length == 2) {
                values.put(parts[0], java.net.URLDecoder.decode(parts[1], StandardCharsets.UTF_8));
            }
        }
        return values;
    }

    // Build a small map for JSON responses
    private Map<String, Object> mapOf(Object... entries) {
        Map<String, Object> output = new LinkedHashMap<>();
        for (int i = 0; i < entries.length; i += 2) {
            output.put(String.valueOf(entries[i]), entries[i + 1]);
        }
        return output;
    }

    // Send a JSON response to the client
    private void sendJson(HttpExchange exchange, int statusCode, Map<String, Object> payload) throws IOException {
        String body = toJson(payload);
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        sendBytes(exchange, statusCode, data);
    }

    // Send a plain text response to the client
    private void sendText(HttpExchange exchange, int statusCode, String text) throws IOException {
        sendBytes(exchange, statusCode, text.getBytes(StandardCharsets.UTF_8));
    }

    // Write bytes to the HTTP response stream
    private void sendBytes(HttpExchange exchange, int statusCode, byte[] data) throws IOException {
        exchange.sendResponseHeaders(statusCode, data.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(data);
        }
    }

    // Convert a map into a compact JSON string
    private String toJson(Map<String, Object> payload) {
        StringBuilder builder = new StringBuilder();
        builder.append("{");
        int index = 0;
        for (Map.Entry<String, Object> entry : payload.entrySet()) {
            if (index++ > 0) {
                builder.append(",");
            }
            builder.append("\"").append(escapeJson(entry.getKey())).append("\":");
            builder.append(valueToJson(entry.getValue()));
        }
        builder.append("}");
        return builder.toString();
    }

    // Convert a value into its JSON representation
    private String valueToJson(Object value) {
        if (value instanceof String) {
            return "\"" + escapeJson((String) value) + "\"";
        }
        if (value instanceof Boolean || value instanceof Number) {
            return String.valueOf(value);
        }
        if (value instanceof Map<?, ?>) {
            return toJson((Map<String, Object>) value);
        }
        if (value instanceof List<?>) {
            StringBuilder builder = new StringBuilder("[");
            List<?> items = (List<?>) value;
            for (int i = 0; i < items.size(); i++) {
                if (i > 0) {
                    builder.append(",");
                }
                builder.append(valueToJson(items.get(i)));
            }
            builder.append("]");
            return builder.toString();
        }
        return "\"" + escapeJson(String.valueOf(value)) + "\"";
    }

    private String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
