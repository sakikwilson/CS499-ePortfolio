import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;

public class MongoUserStore {
    private final MongoCollection<Document> users;

    // Connect to the requested MongoDB collection.
    public MongoUserStore(String connectionString, String databaseName, String collectionName) {
        MongoClient client = MongoClients.create(connectionString);
        MongoDatabase database = client.getDatabase(databaseName);
        this.users = database.getCollection(collectionName);
    }

    // Convert a user profile into the document structure stored in MongoDB.
    public static Document toDocument(UserProfile user) {
        List<Document> entries = new ArrayList<>();
        for (WeightEntry entry : user.getEntries()) {
            entries.add(new Document("date", entry.date).append("weight", entry.weight));
        }

        return new Document("username", user.getUsername())
                .append("password", user.password)
                .append("goalWeight", user.goalWeight)
                .append("unit", user.unit)
                .append("smsNotifications", user.smsNotifications)
                .append("entries", entries);
    }

    // Recreate a UserProfile object from a MongoDB document.
    public static UserProfile fromDocument(Document doc) {
        UserProfile user = new UserProfile(doc.getString("username"), doc.getString("password"));
        user.goalWeight = doc.getDouble("goalWeight");
        user.unit = doc.getString("unit");
        user.smsNotifications = doc.getBoolean("smsNotifications", false);

        List<Document> entries = doc.getList("entries", Document.class);
        if (entries != null) {
            for (Document entry : entries) {
                user.addEntry(new WeightEntry(entry.getString("date"), entry.getDouble("weight")));
            }
        }
        return user;
    }

    // Insert or replace the user's profile in the MongoDB collection.
    public void save(UserProfile user) {
        users.replaceOne(Filters.eq("username", user.getUsername()), toDocument(user), new ReplaceOptions().upsert(true));
    }

    public UserProfile findByUsername(String username) {
        Document doc = users.find(Filters.eq("username", username)).first();
        return doc == null ? null : fromDocument(doc);
    }

    // Return every saved profile from the collection.
    public List<UserProfile> listAll() {
        List<UserProfile> all = new ArrayList<>();
        for (Document doc : users.find()) {
            all.add(fromDocument(doc));
        }
        return all;
    }
}
