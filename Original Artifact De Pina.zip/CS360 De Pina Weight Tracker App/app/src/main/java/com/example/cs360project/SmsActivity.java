package com.example.cs360project;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Manages SMS notification settings
 */
public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "AppPrefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    private TextView statusTextView;
    private SharedPreferences sharedPreferences;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle the back/up button in the Action Bar
        if (item.getItemId() == android.R.id.home) {
            finish(); 
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        // Enable the back arrow in the title bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        statusTextView = findViewById(R.id.textViewSmsStatus);
        Button actionButton = findViewById(R.id.buttonRequestPermission);

        // Update the screen with current setting and permission state
        updateStatus();

        // Show choice dialog when button is clicked
        actionButton.setOnClickListener(v -> showNotificationDialog());
    }

    /** Displays alert for enable or disable SMS alerts */
    private void showNotificationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Notification Settings");
        builder.setMessage("Would you like to enable or disable SMS notifications?");

        builder.setPositiveButton("Enable", (dialog, which) -> {
            // Save preference and check for system permissions
            sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                Toast.makeText(this, "Notifications Enabled", Toast.LENGTH_SHORT).show();
                updateStatus();
            }
        });

        builder.setNegativeButton("Disable", (dialog, which) -> {
            // Disable preference
            sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
            Toast.makeText(this, "Notifications Disabled", Toast.LENGTH_SHORT).show();
            updateStatus();
        });

        builder.setNeutralButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    /** Refresh to reflect the current setting and permission status */
    private void updateStatus() {
        boolean isSmsEnabled = sharedPreferences.getBoolean(KEY_SMS_ENABLED, false);
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (isSmsEnabled && hasPermission) {
            statusTextView.setText(R.string.sms_status_granted);
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else if (isSmsEnabled && !hasPermission) {
            statusTextView.setText("Enabled (Pending Permission)");
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark));
        } else {
            statusTextView.setText(R.string.sms_status_denied);
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Handle the result of the system permission prompt
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications will not work.", Toast.LENGTH_LONG).show();
            }
            updateStatus();
        }
    }
}
