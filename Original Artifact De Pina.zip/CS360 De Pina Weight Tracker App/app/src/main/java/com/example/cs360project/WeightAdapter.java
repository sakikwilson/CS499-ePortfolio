package com.example.cs360project;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Locale;

/**
 * Adapter class that connects the weight data from the database to the RecyclerView
 * list on the screen.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private Cursor cursor;
    private final OnItemClickListener listener;

    /** Interface for handling clicks on specific weight items */
    public interface OnItemClickListener {
        void onDeleteClick(int id);
        void onUpdateClick(int id, String date, double weight);
    }

    public WeightAdapter(Cursor cursor, OnItemClickListener listener) {
        this.cursor = cursor;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the custom row layout (item_weight.xml)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        // Extract data from database cursor at current position
        if (!cursor.moveToPosition(position)) return;

        int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_ID));
        String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
        double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_VALUE));

        // Display data in the UI components
        holder.textViewDate.setText(date);
        holder.textViewWeight.setText(String.format(Locale.getDefault(), "%.1f lbs", weight));

        // Setup click listeners for edit and delete buttons
        holder.buttonDelete.setOnClickListener(v -> listener.onDeleteClick(id));
        holder.buttonEdit.setOnClickListener(v -> listener.onUpdateClick(id, date, weight));
    }

    @Override
    public int getItemCount() {
        return cursor == null ? 0 : cursor.getCount();
    }

    /** Updates the list with new data from the database */
    public void swapCursor(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
        if (newCursor != null) {
            notifyDataSetChanged();
        }
    }

    /** Inner class to hold references to the views for a single list item */
    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDate, textViewWeight;
        ImageButton buttonDelete, buttonEdit;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewWeight = itemView.findViewById(R.id.textViewWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
        }
    }
}
