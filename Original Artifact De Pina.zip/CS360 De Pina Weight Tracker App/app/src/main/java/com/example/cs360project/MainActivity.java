package com.example.cs360project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * User Sign In and Sign Up
 */
public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize database access
        dbHelper = new DatabaseHelper(this);

        // Link UI components
        usernameEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.editTextTextPassword);
        Button loginButton = findViewById(R.id.button5);

        // Process when button is clicked
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Validate inputs
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify credentials
            int userId = dbHelper.checkUser(username, password);
            if (userId != -1) {
                // Successful login for existing user
                navigateToWeightActivity(userId);
            } else {
                // Check if the username is taken with a different password
                if (dbHelper.userExists(username)) {
                    Toast.makeText(this, "Invalid password", Toast.LENGTH_SHORT).show();
                } else {
                    // Register new user automatically if they don't exist
                    long newUserId = dbHelper.addUser(username, password);
                    if (newUserId != -1) {
                        Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                        navigateToWeightActivity((int) newUserId);
                    } else {
                        Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    /**
     * Launches App
     */
    private void navigateToWeightActivity(int userId) {
        Intent intent = new Intent(this, WeightActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }
}
