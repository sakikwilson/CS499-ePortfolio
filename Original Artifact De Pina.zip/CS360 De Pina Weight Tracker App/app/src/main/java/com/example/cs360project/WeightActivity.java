package com.example.cs360project;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Main dashboard for tracking weight.
 */
public class WeightActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private WeightAdapter adapter;
    private int userId;
    private double goalWeight;
    private TextView goalWeightTextView;
    private SharedPreferences sharedPreferences;

    private static final String PREFS_NAME = "AppPrefs";
    private static final String KEY_GOAL_PREFIX = "goal_weight_";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datatable);

        // Get the logged-in user's ID
        userId = getIntent().getIntExtra("USER_ID", -1);
        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Initialize goal weight display
        goalWeightTextView = findViewById(R.id.textViewGoalWeight);
        loadGoalWeight();

        // Set up list with weight data
        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);
        adapter = new WeightAdapter(dbHelper.getAllWeights(userId), new WeightAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int id) {
                // Delete weight entry
                dbHelper.deleteWeight(id);
                refreshData();
            }

            @Override
            public void onUpdateClick(int id, String date, double weight) {
                // Edit existing weight entry
                showWeightDialog(id, date, weight);
            }
        });
        recyclerView.setAdapter(adapter);

        // Add new button
        findViewById(R.id.buttonAdd).setOnClickListener(v -> showWeightDialog(-1, null, 0));
    }

    /** Loads the user's goal weight */
    private void loadGoalWeight() {
        float savedGoal = sharedPreferences.getFloat(KEY_GOAL_PREFIX + userId, 150.0f);
        goalWeight = savedGoal;
        goalWeightTextView.setText(String.format(Locale.getDefault(), "Goal Weight: %.1f lbs", goalWeight));
    }

    /** Saves a new goal weight */
    private void saveGoalWeight(double newGoal) {
        goalWeight = newGoal;
        sharedPreferences.edit().putFloat(KEY_GOAL_PREFIX + userId, (float) newGoal).apply();
        goalWeightTextView.setText(String.format(Locale.getDefault(), "Goal Weight: %.1f lbs", goalWeight));
    }

    /** Refreshes the list data from the database */
    private void refreshData() {
        adapter.swapCursor(dbHelper.getAllWeights(userId));
    }

    /** Displays a dialog to either add or update a weight entry */
    private void showWeightDialog(int id, String existingDate, double existingWeight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(id == -1 ? "Add Weight" : "Update Weight");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        final EditText weightInput = new EditText(this);
        weightInput.setHint("Weight (lbs)");
        weightInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (id != -1) weightInput.setText(String.valueOf(existingWeight));
        layout.addView(weightInput);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String weightStr = weightInput.getText().toString();
            if (!weightStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);
                String date = existingDate != null ? existingDate : new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                if (id == -1) {
                    dbHelper.addWeight(userId, date, weight);
                    checkGoalReached(weight);
                } else {
                    dbHelper.updateWeight(id, date, weight);
                }
                refreshData();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    /** Displays a dialog to set the target goal weight */
    private void showGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText goalInput = new EditText(this);
        goalInput.setHint("Enter Goal (lbs)");
        goalInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        goalInput.setText(String.valueOf(goalWeight));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);
        layout.addView(goalInput);
        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goalStr = goalInput.getText().toString();
            if (!goalStr.isEmpty()) {
                saveGoalWeight(Double.parseDouble(goalStr));
                Toast.makeText(this, "Goal updated", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    /** Checks if the new weight meets the goal and sends SMS if needed */
    private void checkGoalReached(double weight) {
        if (weight <= goalWeight) {
            sendSmsNotification("Congratulations! You reached your goal weight of " + goalWeight + " lbs!");
        }
    }

    /** Sends an SMS notification if permissions and settings allow */
    private void sendSmsNotification(String message) {
        boolean smsEnabledInSettings = sharedPreferences.getBoolean("sms_enabled", false);

        if (smsEnabledInSettings && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5554", null, message, null, null);
                Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
            }
        } else if (!smsEnabledInSettings) {
            Toast.makeText(this, "Goal reached! (SMS notifications are disabled)", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Goal reached! (Enable SMS permission for notifications)", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the options menu (Goal, SMS, Logout)
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle menu item clicks
        int id = item.getItemId();
        if (id == R.id.action_goal) {
            showGoalDialog();
            return true;
        } else if (id == R.id.action_sms) {
            Intent intent = new Intent(this, SmsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_logout) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
